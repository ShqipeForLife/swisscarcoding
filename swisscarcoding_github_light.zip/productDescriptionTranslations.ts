import { index, integer, pgTable, text, timestamp, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { productsTable } from "./products";

export const productDescriptionTranslationsTable = pgTable("product_description_translations", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id").notNull().references(() => productsTable.id, { onDelete: "cascade" }),
  sourceHash: text("source_hash").notNull(),
  targetLocale: text("target_locale").notNull(),
  promptVersion: integer("prompt_version").notNull(),
  translatedDescription: text("translated_description"),
  status: text("status").notNull().default("pending"),
  leaseUntil: timestamp("lease_until", { withTimezone: true }),
  leaseOwner: text("lease_owner"),
  failureUntil: timestamp("failure_until", { withTimezone: true }),
  failureCount: integer("failure_count").notNull().default(0),
  lastError: text("last_error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("product_description_translation_cache_key").on(
    table.sourceHash, table.targetLocale, table.promptVersion,
  ),
  index("product_description_translation_product_idx").on(table.productId),
  index("product_description_translation_lease_idx").on(table.status, table.leaseUntil),
]);

export type ProductDescriptionTranslation = typeof productDescriptionTranslationsTable.$inferSelect;