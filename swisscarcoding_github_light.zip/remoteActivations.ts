import {
  integer,
  check,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { ordersTable } from "./orders";

export const REMOTE_ACTIVATION_STATUSES = [
  "PENDING",
  "READY",
  "DOWNLOADED",
  "ACTIVATED",
  "USED",
  "EXPIRED",
  "CANCELLED",
] as const;
export type RemoteActivationStatus = (typeof REMOTE_ACTIVATION_STATUSES)[number];

export const remoteActivationCasesTable = pgTable(
  "remote_activation_cases",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => ordersTable.id, { onDelete: "cascade" }),
    userId: text("user_id"),
    status: text("status").$type<RemoteActivationStatus>().notNull().default("PENDING"),
    packageTokenHash: text("package_token_hash").notNull(),
    packageVersion: integer("package_version").notNull().default(1),
    packageBindingHash: text("package_binding_hash"),
    unitBindingReference: text("unit_binding_reference"),
    technicalBindingHash: text("technical_binding_hash"),
    downloadCount: integer("download_count").notNull().default(0),
    downloadedAt: timestamp("downloaded_at", { withTimezone: true }),
    activatedAt: timestamp("activated_at", { withTimezone: true }),
    usedAt: timestamp("used_at", { withTimezone: true }),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("remote_activation_cases_order_unique").on(table.orderId),
    uniqueIndex("remote_activation_cases_token_hash_unique").on(table.packageTokenHash),
    check("remote_activation_cases_status_check", sql`${table.status} in ('PENDING','READY','DOWNLOADED','ACTIVATED','USED','EXPIRED','CANCELLED')`),
  ],
);

export const remoteActivationFilesTable = pgTable(
  "remote_activation_files",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    caseId: uuid("case_id")
      .notNull()
      .references(() => remoteActivationCasesTable.id, { onDelete: "cascade" }),
    objectPath: text("object_path").notNull(),
    sha256: text("sha256").notNull(),
    fileName: text("file_name").notNull(),
    contentType: text("content_type").notNull(),
    size: integer("size").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("remote_activation_files_case_unique").on(table.caseId),
    uniqueIndex("remote_activation_files_object_path_unique").on(table.objectPath),
    uniqueIndex("remote_activation_files_sha256_unique").on(table.sha256),
    check("remote_activation_files_size_check", sql`${table.size} > 0`),
  ],
);

export const remoteActivationAuditEventsTable = pgTable("remote_activation_audit_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  caseId: uuid("case_id")
    .notNull()
    .references(() => remoteActivationCasesTable.id, { onDelete: "cascade" }),
  eventType: text("event_type").notNull(),
  fromStatus: text("from_status").$type<RemoteActivationStatus>(),
  toStatus: text("to_status").$type<RemoteActivationStatus>(),
  actorType: text("actor_type").notNull(),
  actorId: text("actor_id"),
  reason: text("reason"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type RemoteActivationCase = typeof remoteActivationCasesTable.$inferSelect;
export type RemoteActivationFile = typeof remoteActivationFilesTable.$inferSelect;
export type RemoteActivationAuditEvent =
  typeof remoteActivationAuditEventsTable.$inferSelect;