import { boolean, pgEnum, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { partialWithoutDefaults } from "./validation";

export const supplierKindEnum = pgEnum("supplier_kind", [
  "manual",
  "aliexpress",
  "cj",
  "eu",
  "ch",
  "other",
]);

export const suppliersTable = pgTable("suppliers", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  kind: supplierKindEnum("kind").notNull().default("manual"),
  website: text("website").notNull().default(""),
  apiDocumentationUrl: text("api_documentation_url").notNull().default(""),
  notes: text("notes").notNull().default(""),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Supplier = typeof suppliersTable.$inferSelect;

const optionalHttpUrl = z.string().refine(
  (value) => value === "" || /^https?:\/\//i.test(value),
  "Must be an HTTP(S) URL",
);
export const supplierWriteSchema = z.object({
  name: z.string().trim().min(1),
  kind: z.enum(["manual", "aliexpress", "cj", "eu", "ch", "other"]).default("manual"),
  website: optionalHttpUrl.default(""),
  api_documentation_url: optionalHttpUrl.default(""),
  notes: z.string().default(""),
  active: z.boolean().default(true),
}).strict();
export const supplierUpdateSchema = partialWithoutDefaults(supplierWriteSchema).refine(
  (value) => Object.keys(value).length > 0,
  "At least one field is required",
);