const fs = require('fs');

let content = fs.readFileSync('artifacts/swiss-car-coding/src/admin/CarPartsTuningPanel.tsx', 'utf8');

content = content.replace(/const \[selection, setSelection\] = useState<Set<string>>\(new Set\(\)\);/, `const [selection, setSelection] = useState<Record<string, CatalogItem>>({});`);
content = content.replace(/const toggleSelection = \(reference: string\) => \{[\s\S]*?setSelection\(newSel\);\n  \};/, `const toggleSelection = (item: CatalogItem) => {
    if (importing) return;
    setSelection(prev => {
      const next = { ...prev };
      if (next[item.reference]) {
        delete next[item.reference];
      } else {
        if (Object.keys(next).length >= 100) {
          alert("Maximum 100 produits à la fois.");
          return prev;
        }
        next[item.reference] = item;
      }
      return next;
    });
  };`);

content = content.replace(/const selectedItemsDetails = catalog\?.items.filter\(i => selection.has\(i.reference\)\) \|\| \[\];/, `const selectedItemsDetails = Object.values(selection);`);
content = content.replace(/selection.has\(item.reference\)/g, `!!selection[item.reference]`);
content = content.replace(/selection.size/g, `Object.keys(selection).length`);
content = content.replace(/toggleSelection\(item.reference\)/g, `toggleSelection(item)`);
content = content.replace(/Array.from\(selection\)/, `Object.keys(selection)`);
content = content.replace(/setSelection\(new Set\(\)\);/g, `setSelection({});`);

fs.writeFileSync('artifacts/swiss-car-coding/src/admin/CarPartsTuningPanel.tsx', content);
