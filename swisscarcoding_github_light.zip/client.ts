import OpenAI from "openai";

const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env ?? {};

if (!env.AI_INTEGRATIONS_OPENAI_BASE_URL) {
  throw new Error("AI_INTEGRATIONS_OPENAI_BASE_URL must be set.");
}
if (!env.AI_INTEGRATIONS_OPENAI_API_KEY) {
  throw new Error("AI_INTEGRATIONS_OPENAI_API_KEY must be set.");
}

export const openai = new OpenAI({
  apiKey: env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});