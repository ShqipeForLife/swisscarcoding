import { pgTable, uuid, text, timestamp, integer } from "drizzle-orm/pg-core";

export const analyticsSessionsTable = pgTable("analytics_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: text("session_id").notNull().unique(),
  ipHash: text("ip_hash"),
  country: text("country"),
  countryCode: text("country_code"),
  deviceType: text("device_type"),
  browser: text("browser"),
  os: text("os"),
  referrer: text("referrer"),
  firstSeen: timestamp("first_seen", { withTimezone: true }).defaultNow().notNull(),
  lastSeen: timestamp("last_seen", { withTimezone: true }).defaultNow().notNull(),
  pageViewsCount: integer("page_views_count").default(1).notNull(),
});

export const analyticsPageviewsTable = pgTable("analytics_pageviews", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionId: text("session_id").notNull(),
  path: text("path").notNull(),
  title: text("title"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  durationMs: integer("duration_ms"),
});
