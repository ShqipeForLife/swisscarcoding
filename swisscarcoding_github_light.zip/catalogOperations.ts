import { boolean, check, index, integer, jsonb, numeric, pgTable, text, timestamp, unique, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
export { optionalHttpUrl, supplierOfferSchema, supplierOffersSchema, replaceOffersSchema } from "./supplierOfferValidation";
import { productsTable } from "./products";
import { suppliersTable } from "./suppliers";

export const brandsTable = pgTable("brands", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  active: boolean("active").notNull().default(true),
});

export const productSupplierOffersTable = pgTable("product_supplier_offers", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id").notNull().references(() => productsTable.id, { onDelete: "cascade" }),
  supplierId: uuid("supplier_id").notNull().references(() => suppliersTable.id),
  supplierReference: text("supplier_reference").notNull().default(""),
  productUrl: text("product_url").notNull().default(""),
  purchasePrice: numeric("purchase_price", { mode: "number" }).notNull().default(0),
  shippingCost: numeric("shipping_cost", { mode: "number" }).notNull().default(0),
  deliveryTime: text("delivery_time").notNull().default(""),
  availability: text("availability").notNull().default("unknown"),
  stockAvailable: integer("stock_available"),
  notes: text("notes").notNull().default(""),
  isPrimary: boolean("is_primary").notNull().default(false),
}, (table) => [
  unique().on(table.productId, table.supplierId),
  uniqueIndex("product_one_primary_offer").on(table.productId).where(sql`${table.isPrimary}`),
  check("product_supplier_offers_purchase_price_check", sql`${table.purchasePrice} >= 0`),
  check("product_supplier_offers_shipping_cost_check", sql`${table.shippingCost} >= 0`),
  check("product_supplier_offers_stock_available_check", sql`${table.stockAvailable} >= 0`),
  check("product_supplier_offers_availability_check", sql`${table.availability} IN ('unknown','in_stock','out_of_stock','on_order')`),
]);

// Deliberately no product/order FK: immutable history survives deletion.
export const stockMovementsTable = pgTable("stock_movements", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id").notNull(),
  productName: text("product_name").notNull(),
  stockSource: text("stock_source").notNull(),
  quantityDelta: integer("quantity_delta").notNull(),
  resultingStock: integer("resulting_stock").notNull(),
  reason: text("reason").notNull(),
  note: text("note").notNull().default(""),
  orderId: uuid("order_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("stock_movements_product_date").on(table.productId, table.createdAt.desc()),
  check("stock_movements_stock_source_check", sql`${table.stockSource} IN ('stock','supplier_stock')`),
  check("stock_movements_resulting_stock_check", sql`${table.resultingStock} >= 0`),
]);

export const stockAdjustmentKeysTable = pgTable("stock_adjustment_keys", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id").notNull(),
  key: text("key").notNull(),
  payload: text("payload").notNull(),
  response: jsonb("response").notNull(),
}, (table) => [unique().on(table.productId, table.key)]);
