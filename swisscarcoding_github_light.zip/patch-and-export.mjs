import fs from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');

async function patchWebJs(file) {
  let s = await fs.readFile(file, 'utf8');
  // Make the Clerk publishable key read window.SWISS_CLERK_PUBLISHABLE_KEY at runtime.
  s = s.replace(/(const [\w$]+=Dw\(window\.location\.hostname,)("pk_[^"]+")\)/, (m, prefix, key) => {
    return `${prefix}(typeof window!=="undefined"&&window.SWISS_CLERK_PUBLISHABLE_KEY?window.SWISS_CLERK_PUBLISHABLE_KEY:${key}))`;
  });
  await fs.writeFile(file, s);
}

async function patchIndexHtml(file) {
  let s = await fs.readFile(file, 'utf8');
  if (!s.includes('SWISS_CLERK_PUBLISHABLE_KEY')) {
    s = s.replace(
      'window.SWISS_API_BASE_URL = "/api";',
      'window.SWISS_API_BASE_URL = "/api";\n      window.SWISS_CLERK_PUBLISHABLE_KEY = "";'
    );
  }
  await fs.writeFile(file, s);
}

async function patchApiDist(file) {
  let s = await fs.readFile(file, 'utf8');
  // Replace the request-origin variable with a PUBLIC_URL-aware siteUrl.
  s = s.replace(
    /const origin = \`\${req\.protocol}:\/\/\${req\.get\("host"\)}\`;/g,
    `const siteUrl = process.env.PUBLIC_URL?.replace(/\\/$/, "") ?? \`\${req.protocol}://\${req.get("host")}\`;`
  );
  // Update success/cancel URLs for appointments and checkout to use the site URL.
  s = s.replace(/success_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?appt=success\`,/g, 'success_url: `${siteUrl}${basePath$1}/?appt=success`,');
  s = s.replace(/cancel_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?appt=cancel\`,/g, 'cancel_url: `${siteUrl}${basePath$1}/?appt=cancel`,');
  s = s.replace(/success_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?payment=success\`,/g, 'success_url: `${siteUrl}${basePath$1}/?payment=success`,');
  s = s.replace(/cancel_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?payment=cancel\`,/g, 'cancel_url: `${siteUrl}${basePath$1}/?payment=cancel`,');
  await fs.writeFile(file, s);
}

async function copyDistToExport(target) {
  const webDist = path.join(root, 'artifacts/swiss-car-coding/dist/public');
  const apiDist = path.join(root, 'artifacts/api-server/dist');
  const targetPublic = path.join(root, target, 'public_html');
  const targetApiDist = path.join(root, target, 'api/dist');
  await fs.rm(targetPublic, { recursive: true, force: true });
  await fs.rm(targetApiDist, { recursive: true, force: true });
  await fs.cp(webDist, targetPublic, { recursive: true });
  await fs.cp(apiDist, targetApiDist, { recursive: true });
}

// Patch web dist
const webJsDir = path.join(root, 'artifacts/swiss-car-coding/dist/public/assets');
const webJsFiles = (await fs.readdir(webJsDir))
  .filter((f) => f.startsWith('index-') && f.endsWith('.js'))
  .map((f) => path.join(webJsDir, f));
for (const f of webJsFiles) await patchWebJs(f);
await patchIndexHtml(path.join(root, 'artifacts/swiss-car-coding/dist/public/index.html'));

// Patch API dist
await patchApiDist(path.join(root, 'artifacts/api-server/dist/index.mjs'));

// Copy to exports
await copyDistToExport('exports/swizzonic');
await copyDistToExport('exports/godaddy');

console.log('Patch and export complete.');
