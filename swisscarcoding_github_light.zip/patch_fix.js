const fs = require('fs');
const path = 'artifacts/swiss-car-coding/src/shop/ShopFilters.tsx';
let filters = fs.readFileSync(path, 'utf8');

// Strip out the incorrectly inserted block
filters = filters.replace(/const handleBrandChange = \([\s\S]*?setActiveEngine\('all'\);\n  };\n\n  /g, '');

// Insert it right before the actual return statement
filters = filters.replace(
  '  return (\n    <div className="flex flex-col gap-4 mb-8">',
  `  const handleBrandChange = (b: string) => {
    setActiveBrand(b);
    setActiveModel('all');
    setActiveYear('all');
    setActiveEngine('all');
  };

  const handleModelChange = (m: string) => {
    setActiveModel(m);
    setActiveYear('all');
    setActiveEngine('all');
  };

  const handleYearChange = (y: string) => {
    setActiveYear(y);
    setActiveEngine('all');
  };

  return (
    <div className="flex flex-col gap-4 mb-8">`
);

fs.writeFileSync(path, filters, 'utf8');
