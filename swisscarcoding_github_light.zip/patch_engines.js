const fs = require('fs');

const path = 'artifacts/swiss-car-coding/src/ShopView.tsx';
let view = fs.readFileSync(path, 'utf8');

const engineReplacement = `const eSet = new Set<string>();
    products.forEach(p => {
      p.compatibility?.forEach(c => {
        const matchesBrand = activeBrand === 'all' || c.brand === activeBrand;
        const matchesModel = activeModel === 'all' || c.model === activeModel;
        let matchesYear = true;
        if (activeYear !== 'all') {
          const yr = Number(activeYear);
          if (c.year_from && yr < c.year_from) matchesYear = false;
          if (c.year_to && yr > c.year_to) matchesYear = false;
        }
        if (matchesBrand && matchesModel && matchesYear) {
          if (c.engine) eSet.add(c.engine);
        }
      });
    });
    return Array.from(eSet).sort();`;

view = view.replace(/const eSet = new Set<string>\(\);\n    products\.forEach\(p => \{[\s\S]*?return Array\.from\(eSet\)\.sort\(\);/, engineReplacement);

fs.writeFileSync(path, view, 'utf8');
