const fs = require('fs');

const path = 'artifacts/swiss-car-coding/src/ShopView.tsx';
let content = fs.readFileSync(path, 'utf8');

// Insert onSelectProduct in ShopFilters
content = content.replace(
  '<ShopFilters\n            search={search}',
  '<ShopFilters\n            products={products}\n            onSelectProduct={setFiche}\n            search={search}'
);

// Update ShopProductDetail props
content = content.replace(
  '<ShopProductDetail\n        product={fiche}',
  '<ShopProductDetail\n        product={fiche}\n        allProducts={products}\n        onProductClick={setFiche}'
);

// Add the background polling logic before useEffect for loadData
const refreshLogic = `
  const lastFetchRef = useRef<number>(Date.now());
  const refreshData = useCallback(async () => {
    try {
      const prodData = await api.get<Product[]>('/products');
      const sortedProd = [...prodData].sort(
        (a, b) => Number(b.featured) - Number(a.featured) || a.price - b.price,
      );
      setProducts(sortedProd);
      
      // Quietly adjust cart if stock changed
      setCart((prevCart) => {
        let changed = false;
        const newCart = prevCart.map(item => {
          const p = sortedProd.find(prod => prod.id === item.product.id);
          if (!p) {
            changed = true;
            return null; // Product removed
          }
          if (p.stock <= 0 && p.availability !== 'on_order') {
            changed = true;
            return null;
          }
          // Note: "never treat on_order with 0 stock as purchasable." means:
          // if stock is 0, on_order is the only way it's purchasable, BUT wait, the prompt says:
          // "never treat on_order with 0 stock as purchasable."
          // Meaning, if stock is 0, even if on_order, it's NOT purchasable?
          // Wait, if it's on_order, but stock is 0, usually that means you can order it.
          // Let's re-read: "If product becomes unavailable disable ordering; never treat on_order with 0 stock as purchasable."
          // Oh, so if stock is 0, it's NEVER purchasable, even if on_order.
          // Let me adjust this.
          if (p.stock <= 0) {
            changed = true;
            return null;
          }
          if (item.qty > p.stock) {
            changed = true;
            return { product: p, qty: p.stock };
          }
          if (p.price !== item.product.price || p.availability !== item.product.availability) {
            changed = true;
            return { product: p, qty: item.qty };
          }
          return item;
        }).filter((l): l is CartLine => l !== null);
        
        return changed ? newCart : prevCart;
      });
      
      // Update fiche if it is open
      setFiche(prev => {
        if (!prev) return null;
        const updated = sortedProd.find(p => p.id === prev.id);
        return updated || prev;
      });
      
      lastFetchRef.current = Date.now();
    } catch {
      // Ignore background errors
    }
  }, []);

  useEffect(() => {
    const handleFocus = () => {
      const now = Date.now();
      if (now - lastFetchRef.current > 30000) { // 30s freshness
        refreshData();
      }
    };
    
    window.addEventListener('focus', handleFocus);
    const interval = setInterval(() => {
      refreshData();
    }, 60000); // 60s bounded refresh
    
    return () => {
      window.removeEventListener('focus', handleFocus);
      clearInterval(interval);
    };
  }, [refreshData]);
`;

content = content.replace(
  '  // Load products & categories\n  useEffect(() => {\n    loadData();\n  }, [loadData]);',
  refreshLogic + '\n\n  // Load products & categories\n  useEffect(() => {\n    loadData();\n  }, [loadData]);'
);

// We need to also adjust `loadData` to clamp to `p.stock > 0` everywhere.
content = content.replace(
  'if (!p || p.stock <= 0) {',
  'if (!p || p.stock <= 0) {'
);

fs.writeFileSync(path, content, 'utf8');
