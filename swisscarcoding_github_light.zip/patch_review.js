const fs = require('fs');

const shopViewPath = 'artifacts/swiss-car-coding/src/ShopView.tsx';
let view = fs.readFileSync(shopViewPath, 'utf8');

// 1. Remove catch on /brands
view = view.replace(
  "api.get<{name: string}[]>('/brands').catch(() => [])",
  "api.get<{name: string}[]>('/brands')"
);

// 2. Fix `years` calculation
const yearsReplacement = `const years = useMemo(() => {
    const ySet = new Set<number>();
    const currentYear = new Date().getFullYear();
    products.forEach(p => {
      p.compatibility?.forEach(c => {
        if (
          (activeBrand === 'all' || c.brand === activeBrand) &&
          (activeModel === 'all' || c.model === activeModel)
        ) {
          if (!c.year_from && !c.year_to) return; // if both null, no specific year constraint applies
          const from = c.year_from || 1990;
          const to = c.year_to || currentYear + 1;
          for (let y = from; y <= to; y++) {
            ySet.add(y);
          }
        }
      });
    });
    return Array.from(ySet).sort((a, b) => b - a);
  }, [products, activeBrand, activeModel]);`;

view = view.replace(/const years = useMemo\(\(\) => \{[\s\S]*?return Array\.from\(ySet\)\.sort\(\);\n  \}, \[products, activeBrand, activeModel\]\);/, yearsReplacement);

// 3. Fix removed product detail preventing stale add
view = view.replace(
  'return updated || prev;',
  'return updated || null;'
);

fs.writeFileSync(shopViewPath, view, 'utf8');

const shopFiltersPath = 'artifacts/swiss-car-coding/src/shop/ShopFilters.tsx';
let filters = fs.readFileSync(shopFiltersPath, 'utf8');

// 4. Implement clearing descendant filters
const selectBrandReplacement = `const handleBrandChange = (b: string) => {
    setActiveBrand(b);
    setActiveModel('all');
    setActiveYear('all');
    setActiveEngine('all');
  };

  const handleModelChange = (m: string) => {
    setActiveModel(m);
    setActiveYear('all');
    setActiveEngine('all');
  };

  const handleYearChange = (y: string) => {
    setActiveYear(y);
    setActiveEngine('all');
  };`;

// Insert the handlers before `return (`
filters = filters.replace('return (', `${selectBrandReplacement}\n\n  return (`);

// Replace Select onChange to use wrappers
filters = filters.replace(
  '<Select \n              value={activeBrand} \n              onChange={setActiveBrand}',
  '<Select \n              value={activeBrand} \n              onChange={handleBrandChange}'
);

filters = filters.replace(
  '<Select \n              value={activeModel} \n              onChange={setActiveModel}',
  '<Select \n              value={activeModel} \n              onChange={handleModelChange}'
);

filters = filters.replace(
  '<Select \n              value={activeYear} \n              onChange={setActiveYear}',
  '<Select \n              value={activeYear} \n              onChange={handleYearChange}'
);

// 5. Accessibility for Autocomplete
filters = filters.replace(
  'value={search}',
  'role="combobox"\n            aria-expanded={showSuggestions}\n            aria-controls="search-suggestions"\n            aria-activedescendant={focusedIndex >= 0 ? `suggestion-${focusedIndex}` : undefined}\n            value={search}'
);

filters = filters.replace(
  '<div className="absolute z-50 top-full left-0 right-0 mt-2 bg-slate-800 border border-white/10 rounded-2xl shadow-xl overflow-hidden">',
  '<div id="search-suggestions" role="listbox" className="absolute z-50 top-full left-0 right-0 mt-2 bg-slate-800 border border-white/10 rounded-2xl shadow-xl overflow-hidden">'
);

filters = filters.replace(
  '<button\n                  key={p.id}',
  '<button\n                  key={p.id}\n                  id={`suggestion-${i}`}\n                  role="option"\n                  aria-selected={i === focusedIndex}'
);

fs.writeFileSync(shopFiltersPath, filters, 'utf8');

console.log('Patches applied.');
