import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const customerProfilesTable = pgTable("customer_profiles", {
  userId: text("user_id").primaryKey(),
  fullName: text("full_name").notNull().default(""),
  phone: text("phone").notNull().default(""),
  company: text("company").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertCustomerProfileSchema = createInsertSchema(customerProfilesTable);
export type InsertCustomerProfile = z.infer<typeof insertCustomerProfileSchema>;
export type CustomerProfile = typeof customerProfilesTable.$inferSelect;

/**
 * Admin-owned customer metadata keyed by a stable aggregate identity
 * (`user:<clerk-id>` or `guest:<normalized-email>`). Orders remain immutable
 * and are aggregated at read time, so guest checkouts are represented too.
 */
export const customerAdminProfilesTable = pgTable("customer_admin_profiles", {
  customerKey: text("customer_key").primaryKey(),
  fullName: text("full_name"),
  phone: text("phone"),
  companyName: text("company_name"),
  notes: text("notes"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const adminCustomerUpdateSchema = z.object({
  full_name: z.string().trim().max(200).optional(),
  phone: z.string().trim().max(50).optional(),
  company_name: z.string().trim().max(200).optional(),
  notes: z.string().trim().max(2000).optional(),
}).strict().refine((value) => Object.keys(value).length > 0, "At least one field is required");
