import { pgTable, pgEnum, text, integer, numeric, boolean, timestamp, uuid, jsonb, check, uniqueIndex } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { suppliersTable } from "./suppliers";
import { partialWithoutDefaults } from "./validation";
import { supplierOffersSchema } from "./supplierOfferValidation";

export const productAvailabilityEnum = pgEnum("product_availability", [
  "in_stock",
  "on_order",
  "out_of_stock",
]);
export const productPricingModeEnum = pgEnum("product_pricing_mode", ["manual", "margin"]);
export const productCurrencyEnum = pgEnum("product_currency", ["CHF", "EUR"]);

export type ProductCompatibility = {
  brand: string;
  model: string;
  year_from: number | null;
  year_to: number | null;
  engine: string;
};

export const productsTable = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  reference: text("reference").notNull().default(""),
  oemReference: text("oem_reference").notNull().default(""),
  compatibility: jsonb("compatibility").$type<ProductCompatibility[]>().notNull().default([]),
  description: text("description").notNull().default(""),
  condition: text("condition"),
  currency: productCurrencyEnum("currency").notNull().default("CHF"),
  price: numeric("price", { mode: "number" }).notNull().default(0),
  wholesalePrice: numeric("wholesale_price", { mode: "number" }).notNull().default(0),
  wholesaleMinQty: integer("wholesale_min_qty").notNull().default(10),
  imageUrl: text("image_url").notNull().default(""),
  imageUrls: jsonb("image_urls").$type<string[]>().notNull().default([]),
  category: text("category").notNull().default("CarPlay"),
  brand: text("brand").notNull().default(""),
  subcategory: text("subcategory").notNull().default(""),
  minimumStock: integer("minimum_stock").notNull().default(0),
  notes: text("notes").notNull().default(""),
  supplierProductUrl: text("supplier_product_url").notNull().default(""),
  stock: integer("stock").notNull().default(0),
  availability: productAvailabilityEnum("availability").notNull().default("in_stock"),
  deliveryTime: text("delivery_time").notNull().default(""),
  shippingFee: numeric("shipping_fee", { mode: "number" }).notNull().default(0),
  featured: boolean("featured").notNull().default(false),
  isPublished: boolean("is_published").notNull().default(true),
  supplier: text("supplier").notNull().default("aliexpress"),
  supplierId: uuid("supplier_id").references(() => suppliersTable.id),
  supplierPid: text("supplier_pid"),
  supplierSku: text("supplier_sku"),
  cost: numeric("cost", { mode: "number" }).notNull().default(0),
  supplierShippingCost: numeric("supplier_shipping_cost", { mode: "number" }).notNull().default(0),
  pricingMode: productPricingModeEnum("pricing_mode").notNull().default("manual"),
  marginPercent: numeric("margin_percent", { mode: "number" }).notNull().default(0),
  supplierStock: integer("supplier_stock").notNull().default(0),
  supplierDeliveryTime: text("supplier_delivery_time").notNull().default(""),
  lastStockSync: timestamp("last_stock_sync", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  check("products_condition_check", sql`${table.condition} IS NULL OR ${table.condition} = ANY (ARRAY['new'::text, 'used'::text, 'refurbished'::text, 'other'::text])`),
  check("products_minimum_stock_check", sql`${table.minimumStock} >= 0`),
  uniqueIndex("products_reference_unique_nonempty").on(sql`lower(btrim(${table.reference}))`).where(sql`btrim(${table.reference}) <> ''`),
]);

export const insertProductSchema = createInsertSchema(productsTable).omit({
  id: true,
  createdAt: true,
});

const httpOrStorageUrl = z.string().refine(
  (value) => {
    if (value === "" || value.startsWith("/api/storage/")) return true;
    try { return ["http:", "https:"].includes(new URL(value).protocol); } catch { return false; }
  },
  "Must be an HTTP(S) URL or an /api/storage path",
);
const compatibilitySchema = z.object({
  brand: z.string().trim().min(1),
  model: z.string().trim().min(1),
  year_from: z.number().int().min(1886).max(2200).nullable(),
  year_to: z.number().int().min(1886).max(2200).nullable(),
  engine: z.string(),
}).refine(
  (value) => value.year_from === null || value.year_to === null || value.year_from <= value.year_to,
  { message: "year_from must not exceed year_to" },
);

export const productWriteSchema = z.object({
  supplier_offers: supplierOffersSchema.optional(),
  name: z.string().trim().min(1),
  reference: z.string().trim().default(""),
  oem_reference: z.string().default(""),
  compatibility: z.array(compatibilitySchema).default([]),
  description: z.string().default(""),
  currency: z.enum(["CHF", "EUR"]).default("CHF"),
  price: z.coerce.number().finite().nonnegative().default(0),
  wholesale_price: z.coerce.number().finite().nonnegative().default(0),
  wholesale_min_qty: z.coerce.number().int().nonnegative().default(10),
  image_url: httpOrStorageUrl.default(""),
  image_urls: z.array(httpOrStorageUrl).default([]),
  category: z.string().trim().min(1).default("CarPlay"),
  brand: z.string().trim().default(""),
  subcategory: z.string().trim().default(""),
  minimum_stock: z.number().int().min(0).max(2147483647).default(0),
  notes: z.string().max(10000).default(""),
  supplier_product_url: z.string().refine((value) => {
    if (!value) return true;
    try { return ["http:", "https:"].includes(new URL(value).protocol); } catch { return false; }
  }, "Must be an HTTP(S) URL").default(""),
  expected_stock: z.number().int().nonnegative().optional(),
  expected_supplier_stock: z.number().int().nonnegative().optional(),
  stock: z.coerce.number().int().nonnegative().max(2147483647).default(0),
  availability: z.enum(["in_stock", "on_order", "out_of_stock"]).default("in_stock"),
  delivery_time: z.string().default(""),
  shipping_fee: z.coerce.number().finite().nonnegative().default(0),
  featured: z.boolean().default(false),
  is_published: z.boolean().default(true),
  supplier_id: z.uuid().nullable().default(null),
  supplier: z.string().default("aliexpress"),
  supplier_pid: z.string().nullable().default(null),
  supplier_sku: z.string().nullable().default(null),
  cost: z.coerce.number().finite().nonnegative().default(0),
  supplier_shipping_cost: z.coerce.number().finite().nonnegative().default(0),
  pricing_mode: z.enum(["manual", "margin"]).default("manual"),
  margin_percent: z.coerce.number().finite().min(0).lt(100).default(0),
  supplier_stock: z.coerce.number().int().nonnegative().max(2147483647).default(0),
  supplier_delivery_time: z.string().default(""),
}).strict();

export const productUpdateSchema = partialWithoutDefaults(productWriteSchema).refine(
  (value) => Object.keys(value).some((key) => key !== "expected_stock" && key !== "expected_supplier_stock"),
  "At least one field is required",
);
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;
