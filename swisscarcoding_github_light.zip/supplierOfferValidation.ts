import { z } from "zod/v4";

export const optionalHttpUrl = z.string().max(4000).refine((value) => {
  if (value === "") return true;
  try { return ["http:", "https:"].includes(new URL(value).protocol); } catch { return false; }
}, "Must be an HTTP(S) URL");

export const supplierOfferSchema = z.object({
  id: z.uuid().optional(),
  supplier_id: z.uuid(),
  supplier_reference: z.string().max(1000).default(""),
  product_url: optionalHttpUrl.default(""),
  purchase_price: z.number().finite().nonnegative().default(0),
  shipping_cost: z.number().finite().nonnegative().default(0),
  delivery_time: z.string().max(1000).default(""),
  availability: z.enum(["unknown", "in_stock", "out_of_stock", "on_order"]).default("unknown"),
  stock_available: z.number().int().min(0).max(2147483647).nullable().default(null),
  expected_stock_available: z.number().int().min(0).max(2147483647).nullable().optional(),
  notes: z.string().max(10000).default(""),
  is_primary: z.boolean().default(false),
}).strict().refine((offer) => offer.stock_available !== null || offer.availability === "unknown",
  "Unknown stock requires unknown availability");

export const supplierOffersSchema = z.array(supplierOfferSchema).max(100)
  .refine((offers) => offers.filter((offer) => offer.is_primary).length <= 1,
    "At most one primary supplier is allowed")
  .refine((offers) => new Set(offers.map((offer) => offer.supplier_id)).size === offers.length,
    "Duplicate suppliers are not allowed");
export const replaceOffersSchema = z.object({ offers: supplierOffersSchema }).strict();