const fs = require('fs');
const path = require('path');

const files = ['fr.json', 'en.json', 'de.json', 'it.json'];
const basePath = 'artifacts/swiss-car-coding/src/i18n';

const updates = {
  fr: {
    subcategory: "Sous-catégorie",
    delivery_clarity: "Informations de livraison",
    similar_products: "Produits similaires",
    preorder: "Précommande",
    categories: {
      "echappement": "Échappement",
      "electricite": "Électricité",
      "pieces-de-performance": "Pièces de performance",
      "jantes-et-pneus": "Jantes et pneus",
      "entretien": "Entretien",
      "freinage": "Freinage",
      "suspension": "Suspension",
      "moteur": "Moteur"
    }
  },
  en: {
    subcategory: "Subcategory",
    delivery_clarity: "Delivery Information",
    similar_products: "Similar Products",
    preorder: "Pre-order",
    categories: {
      "echappement": "Exhaust",
      "electricite": "Electrical",
      "pieces-de-performance": "Performance Parts",
      "jantes-et-pneus": "Wheels and Tires",
      "entretien": "Maintenance",
      "freinage": "Brakes",
      "suspension": "Suspension",
      "moteur": "Engine"
    }
  },
  de: {
    subcategory: "Unterkategorie",
    delivery_clarity: "Lieferinformationen",
    similar_products: "Ähnliche Produkte",
    preorder: "Vorbestellung",
    categories: {
      "echappement": "Auspuff",
      "electricite": "Elektrik",
      "pieces-de-performance": "Leistungsteile",
      "jantes-et-pneus": "Felgen und Reifen",
      "entretien": "Wartung",
      "freinage": "Bremsen",
      "suspension": "Aufhängung",
      "moteur": "Motor"
    }
  },
  it: {
    subcategory: "Sottocategoria",
    delivery_clarity: "Informazioni di consegna",
    similar_products: "Prodotti simili",
    preorder: "Preordine",
    categories: {
      "echappement": "Scarico",
      "electricite": "Elettricità",
      "pieces-de-performance": "Parti ad alte prestazioni",
      "jantes-et-pneus": "Cerchi e pneumatici",
      "entretien": "Manutenzione",
      "freinage": "Freni",
      "suspension": "Sospensione",
      "moteur": "Motore"
    }
  }
};

files.forEach(file => {
  const lang = file.split('.')[0];
  const filePath = path.join(basePath, file);
  const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  
  if (!data.shop) data.shop = {};
  
  data.shop.subcategory = updates[lang].subcategory;
  data.shop.delivery_clarity = updates[lang].delivery_clarity;
  data.shop.similar_products = updates[lang].similar_products;
  data.shop.preorder = updates[lang].preorder;
  // Ensure "on_order" matches "Précommande" for French specifically, but wait, the prompt says "Distinguish status 'Précommande' for on_order in French all matching translations".
  if (lang === 'fr') {
    data.shop.on_order = "Précommande";
  } else if (lang === 'en') {
    data.shop.on_order = "Pre-order";
  } else if (lang === 'de') {
    data.shop.on_order = "Vorbestellung";
  } else if (lang === 'it') {
    data.shop.on_order = "Preordine";
  }
  
  if (!data.shop.categories) data.shop.categories = {};
  Object.assign(data.shop.categories, updates[lang].categories);

  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
});
