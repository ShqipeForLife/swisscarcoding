import { z } from "zod/v4";

/** Zod v4 applies inner defaults even through optional(). Updates must not. */
export function partialWithoutDefaults<S extends Record<string, z.ZodType>>(schema: z.ZodObject<S>) {
  const shape = Object.fromEntries(Object.entries(schema.shape).map(([key, field]) => [
    key, z.optional(field instanceof z.ZodDefault ? field.removeDefault() : field),
  ])) as {
    [K in keyof S]: z.ZodOptional<S[K] extends z.ZodDefault<infer Inner> ? Inner : S[K]>
  };
  return z.object(shape).strict();
}