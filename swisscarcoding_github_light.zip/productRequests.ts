import { pgTable, text, timestamp, uuid, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Manual product-sourcing requests: customers describe a product they want
 * (and/or paste an AliExpress link) while there is no live supplier search.
 * The admin reviews these and manually adds the matching product to the
 * catalog, then marks the request done.
 */
export const productRequestsTable = pgTable("product_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  description: text("description").notNull(),
  aliexpressLink: text("aliexpress_link"),
  status: text("status").notNull().default("pending"),
  adminNote: text("admin_note"),
  userId: text("user_id"),
  partName: text("part_name"),
  vehicleBrand: text("vehicle_brand"),
  vehicleModel: text("vehicle_model"),
  vehicleYear: integer("vehicle_year"),
  vehicleEngine: text("vehicle_engine"),
  vehicleVersion: text("vehicle_version"),
  oemReference: text("oem_reference"),
  comment: text("comment"),
  photoPath: text("photo_path"),
  photoContentType: text("photo_content_type"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("product_requests_user_id_idx").on(table.userId),
]);

export const insertProductRequestSchema = createInsertSchema(productRequestsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertProductRequest = z.infer<typeof insertProductRequestSchema>;
export type ProductRequest = typeof productRequestsTable.$inferSelect;
