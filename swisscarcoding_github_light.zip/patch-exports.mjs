import fs from 'node:fs/promises';

async function patchWebJs(file) {
  let s = await fs.readFile(file, 'utf8');
  // Find the minified variable assigned to "/api" and make it read window.SWISS_API_BASE_URL at runtime.
  s = s.replace(/(\w+)="\/api"/, (m, varName) => {
    return `${varName}=(typeof window!=="undefined"&&window.SWISS_API_BASE_URL?window.SWISS_API_BASE_URL:"/api")`;
  });
  // Make the Clerk publishable key read window.SWISS_CLERK_PUBLISHABLE_KEY at runtime.
  s = s.replace(/(const \w+=Yw\(window\.location\.hostname,)("pk_[^"]+")\)/, (m, prefix, key) => {
    return `${prefix}(typeof window!=="undefined"&&window.SWISS_CLERK_PUBLISHABLE_KEY?window.SWISS_CLERK_PUBLISHABLE_KEY:${key}))`;
  });
  await fs.writeFile(file, s);
}

async function patchIndexHtml(file) {
  let s = await fs.readFile(file, 'utf8');
  if (!s.includes('SWISS_API_BASE_URL')) {
    s = s.replace(
      '  </head>',
      `    <script>
      window.SWISS_API_BASE_URL = "/api";
      window.SWISS_CLERK_PUBLISHABLE_KEY = "";
    </script>
  </head>`
    );
  }
  await fs.writeFile(file, s);
}

async function patchApiDist(file) {
  let s = await fs.readFile(file, 'utf8');
  // Replace the request-origin variable with a PUBLIC_URL-aware one.
  s = s.replace(
    /const origin = \`\${req\.protocol}:\/\/\${req\.get\("host"\)}\`;/g,
    `const siteUrl = process.env.PUBLIC_URL?.replace(/\\/$/, "") ?? \`\${req.protocol}://\${req.get("host")}\`;`
  );
  // Update success/cancel URLs for appointments and checkout to use the site URL.
  s = s.replace(/success_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?appt=success\`,/g, 'success_url: `${siteUrl}${basePath$1}/?appt=success`,');
  s = s.replace(/cancel_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?appt=cancel\`,/g, 'cancel_url: `${siteUrl}${basePath$1}/?appt=cancel`,');
  s = s.replace(/success_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?payment=success\`,/g, 'success_url: `${siteUrl}${basePath$1}/?payment=success`,');
  s = s.replace(/cancel_url: \`\$\{origin\}\$\{basePath(\d+)\}\/\?payment=cancel\`,/g, 'cancel_url: `${siteUrl}${basePath$1}/?payment=cancel`,');
  await fs.writeFile(file, s);
}

const files = {
  webJs: [
    'exports/swizzonic/public_html/assets/index-Mh7gGs2X.js',
    'exports/godaddy/public_html/assets/index-Mh7gGs2X.js',
  ],
  indexHtml: [
    'exports/swizzonic/public_html/index.html',
    'exports/godaddy/public_html/index.html',
  ],
  apiDist: [
    'exports/swizzonic/api/dist/index.mjs',
    'exports/godaddy/api/dist/index.mjs',
  ],
};

for (const f of files.webJs) await patchWebJs(f);
for (const f of files.indexHtml) await patchIndexHtml(f);
for (const f of files.apiDist) await patchApiDist(f);

console.log('Export patches applied.');
