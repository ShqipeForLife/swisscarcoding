import fs from 'fs';
import path from 'path';

const frPath = path.resolve('artifacts/swiss-car-coding/src/i18n/fr.json');
const enPath = path.resolve('artifacts/swiss-car-coding/src/i18n/en.json');
const dePath = path.resolve('artifacts/swiss-car-coding/src/i18n/de.json');
const itPath = path.resolve('artifacts/swiss-car-coding/src/i18n/it.json');

const updateTranslations = () => {
  const translations = [
    {
      file: frPath,
      partners: {
        back: "Retour à l'accueil",
        badge: "Partenaires recommandés",
        title: "Nos partenaires de confiance",
        desc: "Des professionnels que nous recommandons pour vos pièces, accessoires et entretien automobile.",
        items: {
          fast_car: {
            desc: "Vente de pièces détachées et accessoires pour automobiles, entretien et réparation toutes marques, achat / vente / leasing / location de véhicules, et detailing automobile.",
            location: "Suisse romande",
            tags: {
              parts: "Pièces détachées",
              accessories: "Accessoires",
              vehicles: "Véhicules",
              maintenance: "Entretien",
              detailing: "Detailing"
            }
          }
        }
      },
      reviewsItems: {
        r1: { title: "CarPlay activé en 30 minutes", text: "Activation de CarPlay sans fil sur ma Golf, tout s'est fait pendant que j'attendais. Service impeccable et prix très correct. Je recommande à 100%." },
        r2: { title: "Enfin Android Auto sur mon Audi", text: "App-Connect était bloqué d'usine sur mon A4. En quelques minutes tout fonctionnait. Communication claire et travail soigné, un grand merci." },
        r3: { title: "Boîtier sans fil au top", text: "Commandé un boîtier CarPlay sans fil sur la boutique, livré rapidement en Suisse. Plug & play, il se connecte tout seul. Qualité au rendez-vous." },
        r4: { title: "Retrofit BMW parfait", text: "Intégration native CarPlay sur mon écran d'origine, on dirait que c'était monté en usine. Professionnel et de très bon conseil. Je reviendrai." },
        r5: { title: "Rapide et honnête", text: "Rendez-vous facile à prendre, diagnostic offert et tarif annoncé respecté. Rare de trouver un service aussi transparent aujourd'hui." },
        r6: { title: "Commande en gros nickel", text: "En tant que garage, j'ai commandé plusieurs boîtiers au tarif de gros. Prix dégressif appliqué automatiquement et suivi parfait. Partenaire fiable." }
      },
      demo: { nav_active: "Navigation active", in_progress: "En cours", switzerland: "Suisse" }
    },
    {
      file: enPath,
      partners: {
        back: "Back to home",
        badge: "Recommended partners",
        title: "Our trusted partners",
        desc: "Professionals we recommend for your parts, accessories and car maintenance.",
        items: {
          fast_car: {
            desc: "Sale of spare parts and accessories for cars, maintenance and repair of all brands, purchase / sale / leasing / rental of vehicles, and car detailing.",
            location: "French-speaking Switzerland",
            tags: {
              parts: "Spare parts",
              accessories: "Accessories",
              vehicles: "Vehicles",
              maintenance: "Maintenance",
              detailing: "Detailing"
            }
          }
        }
      },
      reviewsItems: {
        r1: { title: "CarPlay activated in 30 minutes", text: "Wireless CarPlay activation on my Golf, everything was done while I waited. Impeccable service and very fair price. I 100% recommend." },
        r2: { title: "Finally Android Auto on my Audi", text: "App-Connect was locked from the factory on my A4. In a few minutes everything was working. Clear communication and neat work, a big thank you." },
        r3: { title: "Top wireless module", text: "Ordered a wireless CarPlay module from the shop, delivered quickly in Switzerland. Plug & play, it connects automatically. Great quality." },
        r4: { title: "Perfect BMW retrofit", text: "Native CarPlay integration on my original screen, looks like it was factory fitted. Professional and very good advice. I will come back." },
        r5: { title: "Fast and honest", text: "Easy to book an appointment, free diagnosis and quoted price respected. Rare to find such a transparent service today." },
        r6: { title: "Flawless wholesale order", text: "As a garage, I ordered several modules at wholesale rates. Volume discount applied automatically and perfect tracking. Reliable partner." }
      },
      demo: { nav_active: "Navigation active", in_progress: "In progress", switzerland: "Switzerland" }
    },
    {
      file: dePath,
      partners: {
        back: "Zurück zur Startseite",
        badge: "Empfohlene Partner",
        title: "Unsere vertrauenswürdigen Partner",
        desc: "Fachleute, die wir für Ihre Teile, Zubehör und Autowartung empfehlen.",
        items: {
          fast_car: {
            desc: "Verkauf von Ersatzteilen und Zubehör für Autos, Wartung und Reparatur aller Marken, Kauf / Verkauf / Leasing / Vermietung von Fahrzeugen und Autopflege (Detailing).",
            location: "Westschweiz",
            tags: {
              parts: "Ersatzteile",
              accessories: "Zubehör",
              vehicles: "Fahrzeuge",
              maintenance: "Wartung",
              detailing: "Detailing"
            }
          }
        }
      },
      reviewsItems: {
        r1: { title: "CarPlay in 30 Minuten aktiviert", text: "Kabellose CarPlay-Aktivierung bei meinem Golf, alles wurde erledigt, während ich wartete. Tadelloser Service und sehr fairer Preis. Ich empfehle es zu 100% weiter." },
        r2: { title: "Endlich Android Auto auf meinem Audi", text: "App-Connect war bei meinem A4 ab Werk gesperrt. In wenigen Minuten funktionierte alles. Klare Kommunikation und saubere Arbeit, ein großes Dankeschön." },
        r3: { title: "Top kabelloses Modul", text: "Ein kabelloses CarPlay-Modul im Shop bestellt, schnell in die Schweiz geliefert. Plug & Play, verbindet sich von selbst. Tolle Qualität." },
        r4: { title: "Perfektes BMW-Retrofit", text: "Native CarPlay-Integration auf meinem Originalbildschirm, sieht aus wie ab Werk eingebaut. Professionell und sehr gute Beratung. Ich komme wieder." },
        r5: { title: "Schnell und ehrlich", text: "Einfache Terminvereinbarung, kostenlose Diagnose und angegebener Preis eingehalten. Selten, heute einen so transparenten Service zu finden." },
        r6: { title: "Tadellose Großbestellung", text: "Als Werkstatt habe ich mehrere Module zu Großhandelspreisen bestellt. Mengenrabatt automatisch angewendet und perfekte Sendungsverfolgung. Zuverlässiger Partner." }
      },
      demo: { nav_active: "Navigation aktiv", in_progress: "Wird ausgeführt", switzerland: "Schweiz" }
    },
    {
      file: itPath,
      partners: {
        back: "Torna alla home",
        badge: "Partner consigliati",
        title: "I nostri partner di fiducia",
        desc: "Professionisti che consigliamo per ricambi, accessori e manutenzione dell'auto.",
        items: {
          fast_car: {
            desc: "Vendita di ricambi e accessori per auto, manutenzione e riparazione di tutte le marche, acquisto / vendita / leasing / noleggio di veicoli e car detailing.",
            location: "Svizzera romanda",
            tags: {
              parts: "Ricambi",
              accessories: "Accessori",
              vehicles: "Veicoli",
              maintenance: "Manutenzione",
              detailing: "Detailing"
            }
          }
        }
      },
      reviewsItems: {
        r1: { title: "CarPlay attivato in 30 minuti", text: "Attivazione di CarPlay wireless sulla mia Golf, tutto è stato fatto mentre aspettavo. Servizio impeccabile e prezzo molto onesto. Lo consiglio al 100%." },
        r2: { title: "Finalmente Android Auto sulla mia Audi", text: "App-Connect era bloccato di fabbrica sulla mia A4. In pochi minuti tutto funzionava. Comunicazione chiara e lavoro curato, un grande ringraziamento." },
        r3: { title: "Modulo wireless al top", text: "Ordinato un modulo CarPlay wireless nel negozio, consegnato rapidamente in Svizzera. Plug & play, si connette da solo. Qualità eccellente." },
        r4: { title: "Retrofit BMW perfetto", text: "Integrazione nativa CarPlay sul mio schermo originale, sembra montato di fabbrica. Professionale e ottimi consigli. Tornerò sicuramente." },
        r5: { title: "Veloce e onesto", text: "Appuntamento facile da prendere, diagnosi gratuita e prezzo preventivato rispettato. Raro trovare un servizio così trasparente oggi." },
        r6: { title: "Ordine all'ingrosso impeccabile", text: "Come officina, ho ordinato diversi moduli a tariffa all'ingrosso. Sconto quantità applicato automaticamente e tracciamento perfetto. Partner affidabile." }
      },
      demo: { nav_active: "Navigazione attiva", in_progress: "In corso", switzerland: "Svizzera" }
    }
  ];

  for (const t of translations) {
    const data = JSON.parse(fs.readFileSync(t.file, 'utf8'));
    
    // Merge data
    data.partners = t.partners;
    data.demo = t.demo;
    if (data.reviews) {
      data.reviews.items = t.reviewsItems;
    }
    
    fs.writeFileSync(t.file, JSON.stringify(data, null, 2));
  }
};

updateTranslations();
