import type { QueryKey, UseMutationOptions, UseMutationResult, UseQueryOptions, UseQueryResult } from '@tanstack/react-query';
import type { AdminCustomer, AdminCustomerUpdate, AdminProduct, CarPartsTuningCatalogPage, CarPartsTuningImportInput, CarPartsTuningImportResult, CarPartsTuningPublishBatchInput, CarPartsTuningPublishBatchResult, CarPartsTuningRefreshInput, CarPartsTuningStatus, CartQuote, CartQuoteRequest, CatalogFacets, CatalogImportCommitInput, CatalogImportInput, Category, CategoryUpdate, CategoryWrite, CheckoutRequest, CheckoutResult, CommitCatalogImport200, EurChfExchangeRate, GetCatalogFacetsParams, GetLocalizedProductDescriptionParams, GetStock200, HealthStatus, ListAdminCustomers200, ListCarPartsTuningCatalogParams, ListStockMovementsParams, LocalizedProductDescription, NotFoundResponse, OrderNotificationRetryResult, OrderNotificationsResponse, PreviewCatalogImport200, Product, ProductOffersInput, ProductUpdate, ProductWrite, StockAdjustmentInput, StockMovement, Supplier, SupplierHandoff, SupplierOffer, SupplierUpdate, SupplierWrite, UnauthorizedResponse, ValidationErrorResponse } from './api.schemas';
import { customFetch } from '../custom-fetch';
import type { ErrorType, BodyType } from '../custom-fetch';
type AwaitedInput<T> = PromiseLike<T> | T;
type Awaited<O> = O extends AwaitedInput<infer T> ? T : never;
type SecondParameter<T extends (...args: never) => unknown> = Parameters<T>[1];
export declare const getGetLocalizedProductDescriptionUrl: (params: GetLocalizedProductDescriptionParams) => string;
/**
 * Lazily translates the canonical description of a product visible in the public catalog.
 */
export declare const getLocalizedProductDescription: (params: GetLocalizedProductDescriptionParams, options?: RequestInit) => Promise<LocalizedProductDescription>;
export declare const getGetLocalizedProductDescriptionQueryKey: (params?: GetLocalizedProductDescriptionParams) => readonly ["/api/catalog/product-description", ...GetLocalizedProductDescriptionParams[]];
export declare const getGetLocalizedProductDescriptionQueryOptions: <TData = Awaited<ReturnType<typeof getLocalizedProductDescription>>, TError = ErrorType<ValidationErrorResponse | NotFoundResponse | void>>(params: GetLocalizedProductDescriptionParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getLocalizedProductDescription>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getLocalizedProductDescription>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetLocalizedProductDescriptionQueryResult = NonNullable<Awaited<ReturnType<typeof getLocalizedProductDescription>>>;
export type GetLocalizedProductDescriptionQueryError = ErrorType<ValidationErrorResponse | NotFoundResponse | void>;
export declare function useGetLocalizedProductDescription<TData = Awaited<ReturnType<typeof getLocalizedProductDescription>>, TError = ErrorType<ValidationErrorResponse | NotFoundResponse | void>>(params: GetLocalizedProductDescriptionParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getLocalizedProductDescription>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetCatalogFacetsUrl: (params?: GetCatalogFacetsParams) => string;
export declare const getCatalogFacets: (params?: GetCatalogFacetsParams, options?: RequestInit) => Promise<CatalogFacets>;
export declare const getGetCatalogFacetsQueryKey: (params?: GetCatalogFacetsParams) => readonly ["/api/catalog/facets", ...GetCatalogFacetsParams[]];
export declare const getGetCatalogFacetsQueryOptions: <TData = Awaited<ReturnType<typeof getCatalogFacets>>, TError = ErrorType<void>>(params?: GetCatalogFacetsParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCatalogFacets>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getCatalogFacets>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetCatalogFacetsQueryResult = NonNullable<Awaited<ReturnType<typeof getCatalogFacets>>>;
export type GetCatalogFacetsQueryError = ErrorType<void>;
export declare function useGetCatalogFacets<TData = Awaited<ReturnType<typeof getCatalogFacets>>, TError = ErrorType<void>>(params?: GetCatalogFacetsParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCatalogFacets>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetEurChfExchangeRateUrl: () => string;
export declare const getEurChfExchangeRate: (options?: RequestInit) => Promise<EurChfExchangeRate>;
export declare const getGetEurChfExchangeRateQueryKey: () => readonly ["/api/exchange-rates/eur-chf"];
export declare const getGetEurChfExchangeRateQueryOptions: <TData = Awaited<ReturnType<typeof getEurChfExchangeRate>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getEurChfExchangeRate>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getEurChfExchangeRate>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetEurChfExchangeRateQueryResult = NonNullable<Awaited<ReturnType<typeof getEurChfExchangeRate>>>;
export type GetEurChfExchangeRateQueryError = ErrorType<unknown>;
export declare function useGetEurChfExchangeRate<TData = Awaited<ReturnType<typeof getEurChfExchangeRate>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getEurChfExchangeRate>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetCarPartsTuningStatusUrl: () => string;
export declare const getCarPartsTuningStatus: (options?: RequestInit) => Promise<CarPartsTuningStatus>;
export declare const getGetCarPartsTuningStatusQueryKey: () => readonly ["/api/admin/suppliers/carpartstuning/status"];
export declare const getGetCarPartsTuningStatusQueryOptions: <TData = Awaited<ReturnType<typeof getCarPartsTuningStatus>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCarPartsTuningStatus>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getCarPartsTuningStatus>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetCarPartsTuningStatusQueryResult = NonNullable<Awaited<ReturnType<typeof getCarPartsTuningStatus>>>;
export type GetCarPartsTuningStatusQueryError = ErrorType<unknown>;
export declare function useGetCarPartsTuningStatus<TData = Awaited<ReturnType<typeof getCarPartsTuningStatus>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCarPartsTuningStatus>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getRefreshCarPartsTuningUrl: () => string;
export declare const refreshCarPartsTuning: (carPartsTuningRefreshInput: CarPartsTuningRefreshInput, options?: RequestInit) => Promise<CarPartsTuningStatus>;
export declare const getRefreshCarPartsTuningMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof refreshCarPartsTuning>>, TError, {
        data: BodyType<CarPartsTuningRefreshInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof refreshCarPartsTuning>>, TError, {
    data: BodyType<CarPartsTuningRefreshInput>;
}, TContext>;
export type RefreshCarPartsTuningMutationResult = NonNullable<Awaited<ReturnType<typeof refreshCarPartsTuning>>>;
export type RefreshCarPartsTuningMutationBody = BodyType<CarPartsTuningRefreshInput>;
export type RefreshCarPartsTuningMutationError = ErrorType<unknown>;
export declare const useRefreshCarPartsTuning: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof refreshCarPartsTuning>>, TError, {
        data: BodyType<CarPartsTuningRefreshInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof refreshCarPartsTuning>>, TError, {
    data: BodyType<CarPartsTuningRefreshInput>;
}, TContext>;
export declare const getListCarPartsTuningCatalogUrl: (params?: ListCarPartsTuningCatalogParams) => string;
export declare const listCarPartsTuningCatalog: (params?: ListCarPartsTuningCatalogParams, options?: RequestInit) => Promise<CarPartsTuningCatalogPage>;
export declare const getListCarPartsTuningCatalogQueryKey: (params?: ListCarPartsTuningCatalogParams) => readonly ["/api/admin/suppliers/carpartstuning/catalog", ...ListCarPartsTuningCatalogParams[]];
export declare const getListCarPartsTuningCatalogQueryOptions: <TData = Awaited<ReturnType<typeof listCarPartsTuningCatalog>>, TError = ErrorType<void>>(params?: ListCarPartsTuningCatalogParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listCarPartsTuningCatalog>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listCarPartsTuningCatalog>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListCarPartsTuningCatalogQueryResult = NonNullable<Awaited<ReturnType<typeof listCarPartsTuningCatalog>>>;
export type ListCarPartsTuningCatalogQueryError = ErrorType<void>;
export declare function useListCarPartsTuningCatalog<TData = Awaited<ReturnType<typeof listCarPartsTuningCatalog>>, TError = ErrorType<void>>(params?: ListCarPartsTuningCatalogParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listCarPartsTuningCatalog>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getImportCarPartsTuningDraftsUrl: () => string;
export declare const importCarPartsTuningDrafts: (carPartsTuningImportInput: CarPartsTuningImportInput, options?: RequestInit) => Promise<CarPartsTuningImportResult>;
export declare const getImportCarPartsTuningDraftsMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof importCarPartsTuningDrafts>>, TError, {
        data: BodyType<CarPartsTuningImportInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof importCarPartsTuningDrafts>>, TError, {
    data: BodyType<CarPartsTuningImportInput>;
}, TContext>;
export type ImportCarPartsTuningDraftsMutationResult = NonNullable<Awaited<ReturnType<typeof importCarPartsTuningDrafts>>>;
export type ImportCarPartsTuningDraftsMutationBody = BodyType<CarPartsTuningImportInput>;
export type ImportCarPartsTuningDraftsMutationError = ErrorType<unknown>;
export declare const useImportCarPartsTuningDrafts: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof importCarPartsTuningDrafts>>, TError, {
        data: BodyType<CarPartsTuningImportInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof importCarPartsTuningDrafts>>, TError, {
    data: BodyType<CarPartsTuningImportInput>;
}, TContext>;
export declare const getPublishCarPartsTuningBatchUrl: () => string;
export declare const publishCarPartsTuningBatch: (carPartsTuningPublishBatchInput: CarPartsTuningPublishBatchInput, options?: RequestInit) => Promise<CarPartsTuningPublishBatchResult>;
export declare const getPublishCarPartsTuningBatchMutationOptions: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof publishCarPartsTuningBatch>>, TError, {
        data: BodyType<CarPartsTuningPublishBatchInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof publishCarPartsTuningBatch>>, TError, {
    data: BodyType<CarPartsTuningPublishBatchInput>;
}, TContext>;
export type PublishCarPartsTuningBatchMutationResult = NonNullable<Awaited<ReturnType<typeof publishCarPartsTuningBatch>>>;
export type PublishCarPartsTuningBatchMutationBody = BodyType<CarPartsTuningPublishBatchInput>;
export type PublishCarPartsTuningBatchMutationError = ErrorType<void>;
export declare const usePublishCarPartsTuningBatch: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof publishCarPartsTuningBatch>>, TError, {
        data: BodyType<CarPartsTuningPublishBatchInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof publishCarPartsTuningBatch>>, TError, {
    data: BodyType<CarPartsTuningPublishBatchInput>;
}, TContext>;
export declare const getListBrandsUrl: () => string;
export declare const listBrands: (options?: RequestInit) => Promise<Category[]>;
export declare const getListBrandsQueryKey: () => readonly ["/api/brands"];
export declare const getListBrandsQueryOptions: <TData = Awaited<ReturnType<typeof listBrands>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listBrands>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listBrands>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListBrandsQueryResult = NonNullable<Awaited<ReturnType<typeof listBrands>>>;
export type ListBrandsQueryError = ErrorType<unknown>;
export declare function useListBrands<TData = Awaited<ReturnType<typeof listBrands>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listBrands>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getCreateBrandUrl: () => string;
export declare const createBrand: (categoryWrite: CategoryWrite, options?: RequestInit) => Promise<Category>;
export declare const getCreateBrandMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createBrand>>, TError, {
        data: BodyType<CategoryWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof createBrand>>, TError, {
    data: BodyType<CategoryWrite>;
}, TContext>;
export type CreateBrandMutationResult = NonNullable<Awaited<ReturnType<typeof createBrand>>>;
export type CreateBrandMutationBody = BodyType<CategoryWrite>;
export type CreateBrandMutationError = ErrorType<unknown>;
export declare const useCreateBrand: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createBrand>>, TError, {
        data: BodyType<CategoryWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof createBrand>>, TError, {
    data: BodyType<CategoryWrite>;
}, TContext>;
export declare const getListAdminBrandsUrl: () => string;
export declare const listAdminBrands: (options?: RequestInit) => Promise<Category[]>;
export declare const getListAdminBrandsQueryKey: () => readonly ["/api/admin/brands"];
export declare const getListAdminBrandsQueryOptions: <TData = Awaited<ReturnType<typeof listAdminBrands>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminBrands>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listAdminBrands>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListAdminBrandsQueryResult = NonNullable<Awaited<ReturnType<typeof listAdminBrands>>>;
export type ListAdminBrandsQueryError = ErrorType<unknown>;
export declare function useListAdminBrands<TData = Awaited<ReturnType<typeof listAdminBrands>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminBrands>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getUpdateBrandUrl: (id: string) => string;
export declare const updateBrand: (id: string, categoryUpdate: CategoryUpdate, options?: RequestInit) => Promise<Category>;
export declare const getUpdateBrandMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateBrand>>, TError, {
        id: string;
        data: BodyType<CategoryUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof updateBrand>>, TError, {
    id: string;
    data: BodyType<CategoryUpdate>;
}, TContext>;
export type UpdateBrandMutationResult = NonNullable<Awaited<ReturnType<typeof updateBrand>>>;
export type UpdateBrandMutationBody = BodyType<CategoryUpdate>;
export type UpdateBrandMutationError = ErrorType<unknown>;
export declare const useUpdateBrand: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateBrand>>, TError, {
        id: string;
        data: BodyType<CategoryUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof updateBrand>>, TError, {
    id: string;
    data: BodyType<CategoryUpdate>;
}, TContext>;
export declare const getDeleteBrandUrl: (id: string) => string;
export declare const deleteBrand: (id: string, options?: RequestInit) => Promise<void>;
export declare const getDeleteBrandMutationOptions: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteBrand>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof deleteBrand>>, TError, {
    id: string;
}, TContext>;
export type DeleteBrandMutationResult = NonNullable<Awaited<ReturnType<typeof deleteBrand>>>;
export type DeleteBrandMutationError = ErrorType<void>;
export declare const useDeleteBrand: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteBrand>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof deleteBrand>>, TError, {
    id: string;
}, TContext>;
export declare const getListProductSuppliersUrl: (id: string) => string;
export declare const listProductSuppliers: (id: string, options?: RequestInit) => Promise<SupplierOffer[]>;
export declare const getListProductSuppliersQueryKey: (id: string) => readonly [`/api/admin/products/${string}/suppliers`];
export declare const getListProductSuppliersQueryOptions: <TData = Awaited<ReturnType<typeof listProductSuppliers>>, TError = ErrorType<unknown>>(id: string, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listProductSuppliers>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listProductSuppliers>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListProductSuppliersQueryResult = NonNullable<Awaited<ReturnType<typeof listProductSuppliers>>>;
export type ListProductSuppliersQueryError = ErrorType<unknown>;
export declare function useListProductSuppliers<TData = Awaited<ReturnType<typeof listProductSuppliers>>, TError = ErrorType<unknown>>(id: string, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listProductSuppliers>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getReplaceProductSuppliersUrl: (id: string) => string;
export declare const replaceProductSuppliers: (id: string, productOffersInput: ProductOffersInput, options?: RequestInit) => Promise<SupplierOffer[]>;
export declare const getReplaceProductSuppliersMutationOptions: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof replaceProductSuppliers>>, TError, {
        id: string;
        data: BodyType<ProductOffersInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof replaceProductSuppliers>>, TError, {
    id: string;
    data: BodyType<ProductOffersInput>;
}, TContext>;
export type ReplaceProductSuppliersMutationResult = NonNullable<Awaited<ReturnType<typeof replaceProductSuppliers>>>;
export type ReplaceProductSuppliersMutationBody = BodyType<ProductOffersInput>;
export type ReplaceProductSuppliersMutationError = ErrorType<void>;
export declare const useReplaceProductSuppliers: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof replaceProductSuppliers>>, TError, {
        id: string;
        data: BodyType<ProductOffersInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof replaceProductSuppliers>>, TError, {
    id: string;
    data: BodyType<ProductOffersInput>;
}, TContext>;
export declare const getGetStockUrl: () => string;
export declare const getStock: (options?: RequestInit) => Promise<GetStock200>;
export declare const getGetStockQueryKey: () => readonly ["/api/admin/stock"];
export declare const getGetStockQueryOptions: <TData = Awaited<ReturnType<typeof getStock>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getStock>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getStock>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetStockQueryResult = NonNullable<Awaited<ReturnType<typeof getStock>>>;
export type GetStockQueryError = ErrorType<unknown>;
export declare function useGetStock<TData = Awaited<ReturnType<typeof getStock>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getStock>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getListStockMovementsUrl: (params?: ListStockMovementsParams) => string;
export declare const listStockMovements: (params?: ListStockMovementsParams, options?: RequestInit) => Promise<StockMovement[]>;
export declare const getListStockMovementsQueryKey: (params?: ListStockMovementsParams) => readonly ["/api/admin/stock/movements", ...ListStockMovementsParams[]];
export declare const getListStockMovementsQueryOptions: <TData = Awaited<ReturnType<typeof listStockMovements>>, TError = ErrorType<unknown>>(params?: ListStockMovementsParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listStockMovements>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listStockMovements>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListStockMovementsQueryResult = NonNullable<Awaited<ReturnType<typeof listStockMovements>>>;
export type ListStockMovementsQueryError = ErrorType<unknown>;
export declare function useListStockMovements<TData = Awaited<ReturnType<typeof listStockMovements>>, TError = ErrorType<unknown>>(params?: ListStockMovementsParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listStockMovements>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getAdjustProductStockUrl: (id: string) => string;
export declare const adjustProductStock: (id: string, stockAdjustmentInput: StockAdjustmentInput, options?: RequestInit) => Promise<AdminProduct>;
export declare const getAdjustProductStockMutationOptions: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof adjustProductStock>>, TError, {
        id: string;
        data: BodyType<StockAdjustmentInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof adjustProductStock>>, TError, {
    id: string;
    data: BodyType<StockAdjustmentInput>;
}, TContext>;
export type AdjustProductStockMutationResult = NonNullable<Awaited<ReturnType<typeof adjustProductStock>>>;
export type AdjustProductStockMutationBody = BodyType<StockAdjustmentInput>;
export type AdjustProductStockMutationError = ErrorType<void>;
export declare const useAdjustProductStock: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof adjustProductStock>>, TError, {
        id: string;
        data: BodyType<StockAdjustmentInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof adjustProductStock>>, TError, {
    id: string;
    data: BodyType<StockAdjustmentInput>;
}, TContext>;
export declare const getPreviewCatalogImportUrl: () => string;
export declare const previewCatalogImport: (catalogImportInput: CatalogImportInput, options?: RequestInit) => Promise<PreviewCatalogImport200>;
export declare const getPreviewCatalogImportMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof previewCatalogImport>>, TError, {
        data: BodyType<CatalogImportInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof previewCatalogImport>>, TError, {
    data: BodyType<CatalogImportInput>;
}, TContext>;
export type PreviewCatalogImportMutationResult = NonNullable<Awaited<ReturnType<typeof previewCatalogImport>>>;
export type PreviewCatalogImportMutationBody = BodyType<CatalogImportInput>;
export type PreviewCatalogImportMutationError = ErrorType<unknown>;
export declare const usePreviewCatalogImport: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof previewCatalogImport>>, TError, {
        data: BodyType<CatalogImportInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof previewCatalogImport>>, TError, {
    data: BodyType<CatalogImportInput>;
}, TContext>;
export declare const getGetCatalogImportTemplateUrl: () => string;
export declare const getCatalogImportTemplate: (options?: RequestInit) => Promise<string>;
export declare const getGetCatalogImportTemplateQueryKey: () => readonly ["/api/admin/catalog/import/template"];
export declare const getGetCatalogImportTemplateQueryOptions: <TData = Awaited<ReturnType<typeof getCatalogImportTemplate>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCatalogImportTemplate>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getCatalogImportTemplate>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetCatalogImportTemplateQueryResult = NonNullable<Awaited<ReturnType<typeof getCatalogImportTemplate>>>;
export type GetCatalogImportTemplateQueryError = ErrorType<unknown>;
export declare function useGetCatalogImportTemplate<TData = Awaited<ReturnType<typeof getCatalogImportTemplate>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCatalogImportTemplate>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getCommitCatalogImportUrl: () => string;
export declare const commitCatalogImport: (catalogImportCommitInput: CatalogImportCommitInput, options?: RequestInit) => Promise<CommitCatalogImport200>;
export declare const getCommitCatalogImportMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof commitCatalogImport>>, TError, {
        data: BodyType<CatalogImportCommitInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof commitCatalogImport>>, TError, {
    data: BodyType<CatalogImportCommitInput>;
}, TContext>;
export type CommitCatalogImportMutationResult = NonNullable<Awaited<ReturnType<typeof commitCatalogImport>>>;
export type CommitCatalogImportMutationBody = BodyType<CatalogImportCommitInput>;
export type CommitCatalogImportMutationError = ErrorType<unknown>;
export declare const useCommitCatalogImport: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof commitCatalogImport>>, TError, {
        data: BodyType<CatalogImportCommitInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof commitCatalogImport>>, TError, {
    data: BodyType<CatalogImportCommitInput>;
}, TContext>;
export declare const getHealthCheckUrl: () => string;
export declare const healthCheck: (options?: RequestInit) => Promise<HealthStatus>;
export declare const getHealthCheckQueryKey: () => readonly ["/api/healthz"];
export declare const getHealthCheckQueryOptions: <TData = Awaited<ReturnType<typeof healthCheck>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof healthCheck>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof healthCheck>>, TError, TData> & {
    queryKey: QueryKey;
};
export type HealthCheckQueryResult = NonNullable<Awaited<ReturnType<typeof healthCheck>>>;
export type HealthCheckQueryError = ErrorType<unknown>;
export declare function useHealthCheck<TData = Awaited<ReturnType<typeof healthCheck>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof healthCheck>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getListProductsUrl: () => string;
export declare const listProducts: (options?: RequestInit) => Promise<Product[]>;
export declare const getListProductsQueryKey: () => readonly ["/api/products"];
export declare const getListProductsQueryOptions: <TData = Awaited<ReturnType<typeof listProducts>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listProducts>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listProducts>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListProductsQueryResult = NonNullable<Awaited<ReturnType<typeof listProducts>>>;
export type ListProductsQueryError = ErrorType<unknown>;
export declare function useListProducts<TData = Awaited<ReturnType<typeof listProducts>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listProducts>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getCreateProductUrl: () => string;
export declare const createProduct: (productWrite: ProductWrite, options?: RequestInit) => Promise<AdminProduct>;
export declare const getCreateProductMutationOptions: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createProduct>>, TError, {
        data: BodyType<ProductWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof createProduct>>, TError, {
    data: BodyType<ProductWrite>;
}, TContext>;
export type CreateProductMutationResult = NonNullable<Awaited<ReturnType<typeof createProduct>>>;
export type CreateProductMutationBody = BodyType<ProductWrite>;
export type CreateProductMutationError = ErrorType<ValidationErrorResponse | UnauthorizedResponse>;
export declare const useCreateProduct: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createProduct>>, TError, {
        data: BodyType<ProductWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof createProduct>>, TError, {
    data: BodyType<ProductWrite>;
}, TContext>;
export declare const getUpdateProductUrl: (id: string) => string;
export declare const updateProduct: (id: string, productUpdate: ProductUpdate, options?: RequestInit) => Promise<AdminProduct>;
export declare const getUpdateProductMutationOptions: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateProduct>>, TError, {
        id: string;
        data: BodyType<ProductUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof updateProduct>>, TError, {
    id: string;
    data: BodyType<ProductUpdate>;
}, TContext>;
export type UpdateProductMutationResult = NonNullable<Awaited<ReturnType<typeof updateProduct>>>;
export type UpdateProductMutationBody = BodyType<ProductUpdate>;
export type UpdateProductMutationError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>;
export declare const useUpdateProduct: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateProduct>>, TError, {
        id: string;
        data: BodyType<ProductUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof updateProduct>>, TError, {
    id: string;
    data: BodyType<ProductUpdate>;
}, TContext>;
export declare const getDeleteProductUrl: (id: string) => string;
export declare const deleteProduct: (id: string, options?: RequestInit) => Promise<void>;
export declare const getDeleteProductMutationOptions: <TError = ErrorType<UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteProduct>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof deleteProduct>>, TError, {
    id: string;
}, TContext>;
export type DeleteProductMutationResult = NonNullable<Awaited<ReturnType<typeof deleteProduct>>>;
export type DeleteProductMutationError = ErrorType<UnauthorizedResponse | NotFoundResponse>;
export declare const useDeleteProduct: <TError = ErrorType<UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteProduct>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof deleteProduct>>, TError, {
    id: string;
}, TContext>;
export declare const getListAdminProductsUrl: () => string;
export declare const listAdminProducts: (options?: RequestInit) => Promise<AdminProduct[]>;
export declare const getListAdminProductsQueryKey: () => readonly ["/api/admin/products"];
export declare const getListAdminProductsQueryOptions: <TData = Awaited<ReturnType<typeof listAdminProducts>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminProducts>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listAdminProducts>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListAdminProductsQueryResult = NonNullable<Awaited<ReturnType<typeof listAdminProducts>>>;
export type ListAdminProductsQueryError = ErrorType<UnauthorizedResponse>;
export declare function useListAdminProducts<TData = Awaited<ReturnType<typeof listAdminProducts>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminProducts>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getListCategoriesUrl: () => string;
export declare const listCategories: (options?: RequestInit) => Promise<Category[]>;
export declare const getListCategoriesQueryKey: () => readonly ["/api/categories"];
export declare const getListCategoriesQueryOptions: <TData = Awaited<ReturnType<typeof listCategories>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listCategories>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listCategories>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListCategoriesQueryResult = NonNullable<Awaited<ReturnType<typeof listCategories>>>;
export type ListCategoriesQueryError = ErrorType<unknown>;
export declare function useListCategories<TData = Awaited<ReturnType<typeof listCategories>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listCategories>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getCreateCategoryUrl: () => string;
export declare const createCategory: (categoryWrite: CategoryWrite, options?: RequestInit) => Promise<Category>;
export declare const getCreateCategoryMutationOptions: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createCategory>>, TError, {
        data: BodyType<CategoryWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof createCategory>>, TError, {
    data: BodyType<CategoryWrite>;
}, TContext>;
export type CreateCategoryMutationResult = NonNullable<Awaited<ReturnType<typeof createCategory>>>;
export type CreateCategoryMutationBody = BodyType<CategoryWrite>;
export type CreateCategoryMutationError = ErrorType<ValidationErrorResponse | UnauthorizedResponse>;
export declare const useCreateCategory: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createCategory>>, TError, {
        data: BodyType<CategoryWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof createCategory>>, TError, {
    data: BodyType<CategoryWrite>;
}, TContext>;
export declare const getListAdminCategoriesUrl: () => string;
export declare const listAdminCategories: (options?: RequestInit) => Promise<Category[]>;
export declare const getListAdminCategoriesQueryKey: () => readonly ["/api/admin/categories"];
export declare const getListAdminCategoriesQueryOptions: <TData = Awaited<ReturnType<typeof listAdminCategories>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminCategories>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listAdminCategories>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListAdminCategoriesQueryResult = NonNullable<Awaited<ReturnType<typeof listAdminCategories>>>;
export type ListAdminCategoriesQueryError = ErrorType<UnauthorizedResponse>;
export declare function useListAdminCategories<TData = Awaited<ReturnType<typeof listAdminCategories>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminCategories>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getUpdateCategoryUrl: (id: string) => string;
export declare const updateCategory: (id: string, categoryUpdate: CategoryUpdate, options?: RequestInit) => Promise<Category>;
export declare const getUpdateCategoryMutationOptions: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateCategory>>, TError, {
        id: string;
        data: BodyType<CategoryUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof updateCategory>>, TError, {
    id: string;
    data: BodyType<CategoryUpdate>;
}, TContext>;
export type UpdateCategoryMutationResult = NonNullable<Awaited<ReturnType<typeof updateCategory>>>;
export type UpdateCategoryMutationBody = BodyType<CategoryUpdate>;
export type UpdateCategoryMutationError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>;
export declare const useUpdateCategory: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateCategory>>, TError, {
        id: string;
        data: BodyType<CategoryUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof updateCategory>>, TError, {
    id: string;
    data: BodyType<CategoryUpdate>;
}, TContext>;
export declare const getDeleteCategoryUrl: (id: string) => string;
export declare const deleteCategory: (id: string, options?: RequestInit) => Promise<void>;
export declare const getDeleteCategoryMutationOptions: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteCategory>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof deleteCategory>>, TError, {
    id: string;
}, TContext>;
export type DeleteCategoryMutationResult = NonNullable<Awaited<ReturnType<typeof deleteCategory>>>;
export type DeleteCategoryMutationError = ErrorType<void>;
export declare const useDeleteCategory: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteCategory>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof deleteCategory>>, TError, {
    id: string;
}, TContext>;
export declare const getListSuppliersUrl: () => string;
export declare const listSuppliers: (options?: RequestInit) => Promise<Supplier[]>;
export declare const getListSuppliersQueryKey: () => readonly ["/api/suppliers"];
export declare const getListSuppliersQueryOptions: <TData = Awaited<ReturnType<typeof listSuppliers>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listSuppliers>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listSuppliers>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListSuppliersQueryResult = NonNullable<Awaited<ReturnType<typeof listSuppliers>>>;
export type ListSuppliersQueryError = ErrorType<UnauthorizedResponse>;
export declare function useListSuppliers<TData = Awaited<ReturnType<typeof listSuppliers>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listSuppliers>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getCreateSupplierUrl: () => string;
export declare const createSupplier: (supplierWrite: SupplierWrite, options?: RequestInit) => Promise<Supplier>;
export declare const getCreateSupplierMutationOptions: <TError = ErrorType<ValidationErrorResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createSupplier>>, TError, {
        data: BodyType<SupplierWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof createSupplier>>, TError, {
    data: BodyType<SupplierWrite>;
}, TContext>;
export type CreateSupplierMutationResult = NonNullable<Awaited<ReturnType<typeof createSupplier>>>;
export type CreateSupplierMutationBody = BodyType<SupplierWrite>;
export type CreateSupplierMutationError = ErrorType<ValidationErrorResponse>;
export declare const useCreateSupplier: <TError = ErrorType<ValidationErrorResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof createSupplier>>, TError, {
        data: BodyType<SupplierWrite>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof createSupplier>>, TError, {
    data: BodyType<SupplierWrite>;
}, TContext>;
export declare const getUpdateSupplierUrl: (id: string) => string;
export declare const updateSupplier: (id: string, supplierUpdate: SupplierUpdate, options?: RequestInit) => Promise<Supplier>;
export declare const getUpdateSupplierMutationOptions: <TError = ErrorType<ValidationErrorResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateSupplier>>, TError, {
        id: string;
        data: BodyType<SupplierUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof updateSupplier>>, TError, {
    id: string;
    data: BodyType<SupplierUpdate>;
}, TContext>;
export type UpdateSupplierMutationResult = NonNullable<Awaited<ReturnType<typeof updateSupplier>>>;
export type UpdateSupplierMutationBody = BodyType<SupplierUpdate>;
export type UpdateSupplierMutationError = ErrorType<ValidationErrorResponse | NotFoundResponse>;
export declare const useUpdateSupplier: <TError = ErrorType<ValidationErrorResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateSupplier>>, TError, {
        id: string;
        data: BodyType<SupplierUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof updateSupplier>>, TError, {
    id: string;
    data: BodyType<SupplierUpdate>;
}, TContext>;
export declare const getDeleteSupplierUrl: (id: string) => string;
export declare const deleteSupplier: (id: string, options?: RequestInit) => Promise<void>;
export declare const getDeleteSupplierMutationOptions: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteSupplier>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof deleteSupplier>>, TError, {
    id: string;
}, TContext>;
export type DeleteSupplierMutationResult = NonNullable<Awaited<ReturnType<typeof deleteSupplier>>>;
export type DeleteSupplierMutationError = ErrorType<void>;
export declare const useDeleteSupplier: <TError = ErrorType<void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteSupplier>>, TError, {
        id: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof deleteSupplier>>, TError, {
    id: string;
}, TContext>;
export declare const getQuoteCartUrl: () => string;
export declare const quoteCart: (cartQuoteRequest: CartQuoteRequest, options?: RequestInit) => Promise<CartQuote>;
export declare const getQuoteCartMutationOptions: <TError = ErrorType<ValidationErrorResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof quoteCart>>, TError, {
        data: BodyType<CartQuoteRequest>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof quoteCart>>, TError, {
    data: BodyType<CartQuoteRequest>;
}, TContext>;
export type QuoteCartMutationResult = NonNullable<Awaited<ReturnType<typeof quoteCart>>>;
export type QuoteCartMutationBody = BodyType<CartQuoteRequest>;
export type QuoteCartMutationError = ErrorType<ValidationErrorResponse>;
export declare const useQuoteCart: <TError = ErrorType<ValidationErrorResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof quoteCart>>, TError, {
        data: BodyType<CartQuoteRequest>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof quoteCart>>, TError, {
    data: BodyType<CartQuoteRequest>;
}, TContext>;
export declare const getListAdminCustomersUrl: () => string;
export declare const listAdminCustomers: (options?: RequestInit) => Promise<ListAdminCustomers200>;
export declare const getListAdminCustomersQueryKey: () => readonly ["/api/admin/customers"];
export declare const getListAdminCustomersQueryOptions: <TData = Awaited<ReturnType<typeof listAdminCustomers>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminCustomers>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listAdminCustomers>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListAdminCustomersQueryResult = NonNullable<Awaited<ReturnType<typeof listAdminCustomers>>>;
export type ListAdminCustomersQueryError = ErrorType<UnauthorizedResponse>;
export declare function useListAdminCustomers<TData = Awaited<ReturnType<typeof listAdminCustomers>>, TError = ErrorType<UnauthorizedResponse>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listAdminCustomers>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getUpdateAdminCustomerUrl: (id: string) => string;
export declare const updateAdminCustomer: (id: string, adminCustomerUpdate: AdminCustomerUpdate, options?: RequestInit) => Promise<AdminCustomer>;
export declare const getUpdateAdminCustomerMutationOptions: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateAdminCustomer>>, TError, {
        id: string;
        data: BodyType<AdminCustomerUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof updateAdminCustomer>>, TError, {
    id: string;
    data: BodyType<AdminCustomerUpdate>;
}, TContext>;
export type UpdateAdminCustomerMutationResult = NonNullable<Awaited<ReturnType<typeof updateAdminCustomer>>>;
export type UpdateAdminCustomerMutationBody = BodyType<AdminCustomerUpdate>;
export type UpdateAdminCustomerMutationError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>;
export declare const useUpdateAdminCustomer: <TError = ErrorType<ValidationErrorResponse | UnauthorizedResponse | NotFoundResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateAdminCustomer>>, TError, {
        id: string;
        data: BodyType<AdminCustomerUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof updateAdminCustomer>>, TError, {
    id: string;
    data: BodyType<AdminCustomerUpdate>;
}, TContext>;
export declare const getGetSupplierHandoffUrl: (id: string) => string;
export declare const getSupplierHandoff: (id: string, options?: RequestInit) => Promise<SupplierHandoff>;
export declare const getGetSupplierHandoffQueryKey: (id: string) => readonly [`/api/admin/orders/${string}/supplier-handoff`];
export declare const getGetSupplierHandoffQueryOptions: <TData = Awaited<ReturnType<typeof getSupplierHandoff>>, TError = ErrorType<UnauthorizedResponse | NotFoundResponse | void>>(id: string, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getSupplierHandoff>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getSupplierHandoff>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetSupplierHandoffQueryResult = NonNullable<Awaited<ReturnType<typeof getSupplierHandoff>>>;
export type GetSupplierHandoffQueryError = ErrorType<UnauthorizedResponse | NotFoundResponse | void>;
export declare function useGetSupplierHandoff<TData = Awaited<ReturnType<typeof getSupplierHandoff>>, TError = ErrorType<UnauthorizedResponse | NotFoundResponse | void>>(id: string, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getSupplierHandoff>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetOrderNotificationsUrl: (id: string) => string;
export declare const getOrderNotifications: (id: string, options?: RequestInit) => Promise<OrderNotificationsResponse>;
export declare const getGetOrderNotificationsQueryKey: (id: string) => readonly [`/api/admin/orders/${string}/notifications`];
export declare const getGetOrderNotificationsQueryOptions: <TData = Awaited<ReturnType<typeof getOrderNotifications>>, TError = ErrorType<UnauthorizedResponse | NotFoundResponse>>(id: string, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getOrderNotifications>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getOrderNotifications>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetOrderNotificationsQueryResult = NonNullable<Awaited<ReturnType<typeof getOrderNotifications>>>;
export type GetOrderNotificationsQueryError = ErrorType<UnauthorizedResponse | NotFoundResponse>;
export declare function useGetOrderNotifications<TData = Awaited<ReturnType<typeof getOrderNotifications>>, TError = ErrorType<UnauthorizedResponse | NotFoundResponse>>(id: string, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getOrderNotifications>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getRetryOrderNotificationUrl: (id: string, notificationId: string) => string;
export declare const retryOrderNotification: (id: string, notificationId: string, options?: RequestInit) => Promise<OrderNotificationRetryResult>;
export declare const getRetryOrderNotificationMutationOptions: <TError = ErrorType<UnauthorizedResponse | NotFoundResponse | void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof retryOrderNotification>>, TError, {
        id: string;
        notificationId: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof retryOrderNotification>>, TError, {
    id: string;
    notificationId: string;
}, TContext>;
export type RetryOrderNotificationMutationResult = NonNullable<Awaited<ReturnType<typeof retryOrderNotification>>>;
export type RetryOrderNotificationMutationError = ErrorType<UnauthorizedResponse | NotFoundResponse | void>;
export declare const useRetryOrderNotification: <TError = ErrorType<UnauthorizedResponse | NotFoundResponse | void>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof retryOrderNotification>>, TError, {
        id: string;
        notificationId: string;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof retryOrderNotification>>, TError, {
    id: string;
    notificationId: string;
}, TContext>;
export declare const getCheckoutUrl: () => string;
export declare const checkout: (checkoutRequest: CheckoutRequest, options?: RequestInit) => Promise<CheckoutResult>;
export declare const getCheckoutMutationOptions: <TError = ErrorType<ValidationErrorResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof checkout>>, TError, {
        data: BodyType<CheckoutRequest>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof checkout>>, TError, {
    data: BodyType<CheckoutRequest>;
}, TContext>;
export type CheckoutMutationResult = NonNullable<Awaited<ReturnType<typeof checkout>>>;
export type CheckoutMutationBody = BodyType<CheckoutRequest>;
export type CheckoutMutationError = ErrorType<ValidationErrorResponse>;
export declare const useCheckout: <TError = ErrorType<ValidationErrorResponse>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof checkout>>, TError, {
        data: BodyType<CheckoutRequest>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof checkout>>, TError, {
    data: BodyType<CheckoutRequest>;
}, TContext>;
export {};
//# sourceMappingURL=api.d.ts.map