const fs = require('fs');

const path = 'artifacts/swiss-car-coding/src/ShopView.tsx';
let content = fs.readFileSync(path, 'utf8');

// We need to add state for `apiBrands`
content = content.replace(
  'const [categories, setCategories] = useState<Category[]>([]);',
  'const [categories, setCategories] = useState<Category[]>([]);\n  const [apiBrands, setApiBrands] = useState<{name: string}[]>([]);'
);

// We need to fetch it in `loadData`
content = content.replace(
  'api.get<Category[]>(\'/categories\')\n      ]);',
  'api.get<Category[]>(\'/categories\'),\n        api.get<{name: string}[]>(\'/brands\').catch(() => [])\n      ]);'
);

content = content.replace(
  'const [prodData, catData] = await Promise.all([',
  'const [prodData, catData, brandsData] = await Promise.all(['
);

content = content.replace(
  'setCategories(catData.filter(c => c.active));',
  'setCategories(catData.filter(c => c.active));\n      if (brandsData) setApiBrands(brandsData);'
);

// Update `brands` useMemo to combine apiBrands and products brands
content = content.replace(
  'const brands = useMemo(() => {\n    const bSet = new Set<string>();\n    products.forEach(p => {\n      p.compatibility?.forEach(c => {\n        if (c.brand) bSet.add(c.brand);\n      });\n    });\n    return Array.from(bSet).sort();\n  }, [products]);',
  'const brands = useMemo(() => {\n    const bSet = new Set<string>();\n    apiBrands.forEach(b => bSet.add(b.name));\n    products.forEach(p => {\n      if (p.brand) bSet.add(p.brand);\n      p.compatibility?.forEach(c => {\n        if (c.brand) bSet.add(c.brand);\n      });\n    });\n    return Array.from(bSet).sort();\n  }, [products, apiBrands]);'
);

fs.writeFileSync(path, content, 'utf8');
