import { pgTable, text, uuid, integer, timestamp, index, foreignKey } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { ordersTable } from "./orders";

// Preserve the existing production outbox and its delivery history on publication.
export const orderNotificationsTable = pgTable("order_notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  orderId: uuid("order_id").notNull(),
  eventKey: text("event_key").notNull().unique("order_notifications_event_key_key"),
  recipient: text("recipient").notNull(),
  subject: text("subject").notNull(),
  html: text("html").notNull(),
  attempts: integer("attempts").notNull().default(0),
  availableAt: timestamp("available_at", { withTimezone: true }).notNull().defaultNow(),
  leaseUntil: timestamp("lease_until", { withTimezone: true }),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  lastError: text("last_error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  foreignKey({
    name: "order_notifications_order_id_fkey",
    columns: [table.orderId],
    foreignColumns: [ordersTable.id],
  }),
  index("order_notifications_pending_idx").on(table.availableAt).where(sql`${table.sentAt} IS NULL`),
]);