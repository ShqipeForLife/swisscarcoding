export { openai } from "./client";
//# sourceMappingURL=index.d.ts.map