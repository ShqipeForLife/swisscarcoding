import { pgTable, text, numeric, timestamp, uuid, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import { z } from "zod/v4";
import { productCurrencyEnum } from "./products";

export type OrderItem = {
  product_id: string;
  name: string;
  qty: number;
  unit_price: number;
  reference?: string | null;
  oem_reference?: string | null;
  shipping_fee?: number;
  supplier?: string | null;
  stock_source?: "stock" | "supplier_stock" | "supplier_availability";
};

export const ordersTable = pgTable("orders", {
  id: uuid("id").primaryKey().defaultRandom(),
  orderNumber: text("order_number")
    .notNull()
    .default(sql`'SCC-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))`)
    .unique(),
  userId: text("user_id"),
  companyName: text("company_name"),
  contactName: text("contact_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address"),
  shipAddress: text("ship_address"),
  shipCity: text("ship_city"),
  shipZip: text("ship_zip"),
  shipProvince: text("ship_province"),
  shipCountry: text("ship_country").notNull().default("CH"),
  items: jsonb("items").$type<OrderItem[]>().notNull().default([]),
  currency: productCurrencyEnum("currency").notNull().default("CHF"),
  subtotal: numeric("subtotal", { mode: "number" }).notNull().default(0),
  shippingFee: numeric("shipping_fee", { mode: "number" }).notNull().default(0),
  deliveryMethod: text("delivery_method").notNull().default("standard"),
  deliveryLabel: text("delivery_label").notNull().default("Livraison à domicile"),
  total: numeric("total", { mode: "number" }).notNull().default(0),
  notes: text("notes"),
  status: text("status").notNull().default("pending"),
  paymentMethod: text("payment_method").notNull().default("bank_transfer"),
  paymentStatus: text("payment_status").notNull().default("unpaid"),
  stripeSessionId: text("stripe_session_id"),
  reservationStatus: text("reservation_status").notNull().default("none"),
  reservedUntil: timestamp("reserved_until", { withTimezone: true }),
  stockConsumedAt: timestamp("stock_consumed_at", { withTimezone: true }),
  fulfillmentStatus: text("fulfillment_status").notNull().default("pending"),
  supplier: text("supplier").notNull().default("aliexpress"),
  supplierOrderId: text("supplier_order_id"),
  trackingNumber: text("tracking_number"),
  trackingUrl: text("tracking_url"),
  carrier: text("carrier"),
  supplierError: text("supplier_error"),
  fulfilledAt: timestamp("fulfilled_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  id: true,
  createdAt: true,
});
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
