const fs = require('fs');
const path1 = 'artifacts/swiss-car-coding/src/ShopView.tsx';
let view = fs.readFileSync(path1, 'utf8');

// Add state
view = view.replace(
  'const [activeCat, setActiveCat] = useState(\'all\');',
  'const [activeCat, setActiveCat] = useState(\'all\');\n  const [activeSubcat, setActiveSubcat] = useState(\'all\');'
);

// Add to derived filtered
view = view.replace(
  'const matchesCat = activeCat === \'all\' || p.category.toLowerCase() === activeCat.toLowerCase();',
  'const matchesCat = activeCat === \'all\' || p.category.toLowerCase() === activeCat.toLowerCase();\n      const matchesSubcat = activeSubcat === \'all\' || (p.subcategory && p.subcategory.toLowerCase() === activeSubcat.toLowerCase());'
);

view = view.replace(
  'if (!matchesCat || !matchesText) return false;',
  'if (!matchesCat || !matchesSubcat || !matchesText) return false;'
);

view = view.replace(
  '[products, search, activeCat, activeBrand, activeModel, activeYear, activeEngine, minPrice, maxPrice, activeAvailability]',
  '[products, search, activeCat, activeSubcat, activeBrand, activeModel, activeYear, activeEngine, minPrice, maxPrice, activeAvailability]'
);

// Derive subcategories based on activeCat
view = view.replace(
  'const brands = useMemo',
  'const subcategories = useMemo(() => {\n    const sSet = new Set<string>();\n    products.forEach(p => {\n      if (p.subcategory && (activeCat === \'all\' || p.category.toLowerCase() === activeCat.toLowerCase())) {\n        sSet.add(p.subcategory);\n      }\n    });\n    return Array.from(sSet).sort();\n  }, [products, activeCat]);\n\n  const brands = useMemo'
);

// Pass to ShopFilters
view = view.replace(
  'activeCat={activeCat}\n            setActiveCat={setActiveCat}',
  'activeCat={activeCat}\n            setActiveCat={(c) => { setActiveCat(c); setActiveSubcat(\'all\'); }}\n            subcategories={subcategories}\n            activeSubcat={activeSubcat}\n            setActiveSubcat={setActiveSubcat}'
);

fs.writeFileSync(path1, view, 'utf8');

const path2 = 'artifacts/swiss-car-coding/src/shop/ShopFilters.tsx';
let filters = fs.readFileSync(path2, 'utf8');

filters = filters.replace(
  'activeCat: string;\n  setActiveCat: (c: string) => void;',
  'activeCat: string;\n  setActiveCat: (c: string) => void;\n  subcategories: string[];\n  activeSubcat: string;\n  setActiveSubcat: (c: string) => void;'
);

filters = filters.replace(
  'activeCat,\n  setActiveCat,',
  'activeCat,\n  setActiveCat,\n  subcategories,\n  activeSubcat,\n  setActiveSubcat,'
);

// Add the subcategory filter right after category pills
filters = filters.replace(
  '{/* Advanced Filters */}',
  `{subcategories.length > 0 && activeCat !== 'all' && (
        <div className="flex flex-wrap gap-2 items-center mt-2">
          <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold mr-2">{t('shop.subcategory')}</span>
          <CatPill label={t('shop.all')} active={activeSubcat === 'all'} onClick={() => setActiveSubcat('all')} />
          {subcategories.map(sc => (
            <CatPill
              key={sc}
              label={sc}
              active={activeSubcat === sc}
              onClick={() => setActiveSubcat(sc)}
            />
          ))}
        </div>
      )}
      
      {/* Advanced Filters */}`
);

fs.writeFileSync(path2, filters, 'utf8');
